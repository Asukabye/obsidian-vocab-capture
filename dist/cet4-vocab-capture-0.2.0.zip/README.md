# CET4 生词捕获（Obsidian 插件）

生词本现在是 **整个 vault 共享的一个单词集合**。在阅读视图或编辑视图中选中英文单词后按快捷键：

- 未收录的词 → 加入词表，并在所有 Markdown 文件中高亮
- 已收录的词 → 从词表移除，所有高亮同步消失
- 也可以直接编辑 `生词本.txt` 增加/删除单词，插件会自动重新加载

高亮不修改 md 源文件：

- 阅读视图：`CSS Custom Highlight API`
- 编辑视图：CodeMirror 6 Decoration

![阅读视图高亮示意（模拟）](docs/preview.png)

> 示意图：青绿色为插件高亮；`==26==` 的黄色为原有填空高亮；代码块默认不参与。

---

## 安装

插件目录需要放在目标 vault 的：

```text
<vault>/.obsidian/plugins/cet4-vocab-capture/
```

至少包含这三个文件：

```text
manifest.json
main.js
styles.css
```

然后：

1. 用 Obsidian 打开目标 vault（本项目是 `CET4-真题`）。
2. 设置 → 第三方插件（社区插件）→ 关闭“安全模式/受限模式”。
3. 在已安装插件列表中启用 **CET4 生词捕获**。
4. 如果列表里没有，点“刷新”或重启 Obsidian。

> 本插件是单文件 `main.js`，直接 `require("obsidian")` 和 `require("@codemirror/view")`，不需要 npm、不需要构建。

---

## 使用

### 通过快捷键增删

1. 打开任意 Markdown 文件，切换到 **阅读视图** 或 **编辑视图**。
2. 用鼠标双击选中一个英文单词（也可以拖选）。
3. 按下默认快捷键 `Alt+W`：
   - 如果该词还不在词集中：新增并高亮；
   - 如果该词已在词集中：移除并取消高亮。

选区只支持一个英文单词；多词、数字、符号会被拒绝。

> toggle 判断的是“该词是否在词集中”，不是“当前屏幕上是否正好有青绿色高亮”。因此，如果词在词集中但因为代码/表格设置或词形变化没有显示高亮，按键仍会把它移除。

### 直接编辑生词本

默认词表：

```text
<vault>/生词本.txt
```

一行一个单词。直接在 Obsidian 中编辑该文件：

- 增加一行 → 保存/自动保存后，所有打开的文件出现该词的高亮；
- 删除一行 → 保存/自动保存后，高亮消失。

内容示例：

```text
beneficial
decline
moderate
people's
up-to-date
```

词表是集合：重复词、大小写变体会被归一化并去重。

---

## 设置

在 设置 → 第三方插件 → CET4 生词捕获 中：

| 设置 | 默认 | 说明 |
|---|---|---|
| 生词本文件 | `生词本.txt` | 相对 vault 根目录；也可填绝对路径（仅桌面版） |
| 收录快捷键 | `Alt+W` | 点“录制”后按新键；支持单键或组合键 |
| 高亮颜色 | `rgba(64, 190, 160, 0.28)` | 任意 CSS 颜色 |
| 包含表格 | 开 | 表格中的单词也高亮；关闭后阅读视图和编辑视图都跳过表格行 |
| 包含代码 | 关 | 行内代码/代码块默认不处理 |
| 跳过已有高亮 | 开 | 跳过 `==26==` 这类已有 `<mark>`，避免叠色 |
| 按字母排序 | 开 | 关闭后按首次收录顺序写入 |

> 单键快捷键只在“阅读/编辑视图有选区”时生效；在输入框、命令面板、设置弹窗中不会拦截按键。

---

## 高亮范围

- **vault 内所有 Markdown 文件**
- 阅读视图 + 编辑视图（Live Preview / Source）
- 生词本自身不参与高亮
- Canvas、PDF、纯文本文件不处理

---

## 支持哪些 md 格式

阅读视图基于渲染后的 DOM，天然支持：

- YAML frontmatter（不渲染，忽略）
- `#` ~ `######` 标题
- `> [!info]`、`> [!quote]`、`> [!article]`、`> [!questions]`、`> [!example]` 等 callout
- callout 内的多层 blockquote
- `**P1**`、`**A)**`、`**36.**` 等加粗标签
- 链接 `[文字](url)`（只处理文字，不碰 href）
- 表格 `td` / `th`（可关闭）
- 列表 `li`
- 行内代码、代码块（默认跳过）
- 已有的 `==高亮==`（默认跳过）
- 弯引号 `people’s`、不同连字符 `up‑to‑date`
- 被格式拆开的单词，例如 `**decline**d`：按块拼接文本节点，用跨节点 `Range` 高亮

编辑视图基于源码做 CM6 Decoration，覆盖 Live Preview 和 Source。默认跳过 frontmatter、代码、URL、已有 `==高亮==`；关闭“包含表格”时跳过表格行。

---

## 实现要点

- **选词**：阅读视图用 `window.getSelection()`；编辑视图用 `editor.getSelection()`；要求只有一个选区。
- **词集**：`Set` 去重；按设置排序；UTF-8、一行一词；vault 内用 `vault.adapter`，绝对路径用 Node `fs`。
- **匹配**：Unicode 整词正则，大小写不敏感；`people's` 可匹配 `people’s`；`up-to-date` 可匹配非标准连字符。
- **阅读视图**：按 `p`/`li`/`td`/`th`/`h1`-`h6`/callout 标题分组，拼接文本节点并映射回 `Range`，写入 `CSS.highlights`。
- **编辑视图**：`registerEditorExtension` + `ViewPlugin` + `Decoration.mark`；只看 `EditorView.visibleRanges`，词表变化时通过 `StateEffect` 触发重建。
- **刷新**：`registerMarkdownPostProcessor`、`layout-change`、`active-leaf-change`、`file-open`、阅读视图 `MutationObserver`，以及编辑器的 CM6 更新。
- **直接编辑词表**：`vault` 的 `modify` / `create` / `delete` / `rename` 事件会重新加载词集并刷新高亮。
- **清理**：`onunload` 删除 `CSS.highlights` 注册、断开 observer、清空编辑器视图集合。

---

## 已知边界

- **精确整词**：收录 `decline` 不会自动高亮 `declined`/`declining`。词形变化是后续增强，避免误伤。
- **编辑视图的 Markdown 标记**：编辑器基于源码匹配；`**decline**d` 这种“加粗部分 + 后缀”在源码中不是连续的 `declined`，编辑视图可能只高亮 `decline` 部分，阅读视图不受影响。
- **编辑视图的代码/URL**：默认跳过；打开“包含代码”后，源码中的 fenced code、行内代码也会参与匹配。
- **多窗口**：阅读视图的 CSS Highlight 覆盖主窗口；Obsidian popout 窗口暂未单独处理。CM6 编辑视图通常可随扩展生效，但未做专门验证。
- **高亮是运行时效果**：插件禁用后高亮消失，但 txt 词集保留；不写入 md。
- **词表格式**：txt 中只应有“一行一个单词”；注释、短语、数字行会被忽略，并在下次写入时被清理。
- **绝对路径词表**：桌面版可用，但不会监听 vault 外部的文件变化；修改后执行“重新加载生词本”。
- **不要在 Obsidian 里同时手动编辑词表并按键收录**：自动写入可能覆盖未保存的手动修改。

---

## 故障排查

| 现象 | 检查 |
|---|---|
| 按快捷键没反应 | 是否在阅读/编辑视图？是否有选区？快捷键是否被其他插件占用？ |
| 有“已收录”但没有高亮 | 该词是否在代码/URL/表格中被排除？是否在生词本文件自身？ |
| 高亮没有出现在别的文章 | 词表是否已加载？编辑视图是否已打开/刷新？ |
| 编辑视图没有高亮 | Obsidian 是否成功加载 `@codemirror/view`；可在开发者工具查看 `[cet4-vocab-capture]` 警告 |
| 重启后没有高亮 | 打开任意 Markdown 阅读/编辑视图；再执行命令“刷新单词高亮” |
| 直接改 txt 后没变化 | 确认已保存；执行命令“重新加载生词本” |
| 词表路径改了但词没变 | 在设置里点“重新加载”，或执行命令“重新加载生词本” |

调试可在 Obsidian 开发者工具（Ctrl+Shift+I）控制台查看 `[cet4-vocab-capture]` 前缀的错误。

---

## 开发与测试

```bash
# 语法检查
node --check main.js

# 纯函数单元测试（无需依赖）
node tests/core.test.js

# 可选：DOM 层测试（需要 jsdom）
node tests/dom.test.js
```

单元测试覆盖：单词规范化、txt 解析/序列化、整词边界、弯引号/连字符变体、快捷键解析、vault 路径规范化、词集增删、编辑视图跳过范围与 Decoration 构建。
